import React from "react";

const Modal = ({ item, onClose }) => {
  return (
    <div className="modal">
      <div className="modal-content">
        <h3>Details for {item.name}</h3>
        <p>Likes: {item.likes}</p>
        <p>Shares: {item.shares}</p>
        <p>Comments: {item.comments}</p>
        <p>Followers: {item.followers}</p>
        <p>Category: {item.category}</p>
        <p>Location: {item.location}</p>
        <button onClick={onClose}>Close</button>
      </div>
    </div>
  );
};

export default Modal;
