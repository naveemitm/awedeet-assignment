import React from "react";

const ItemCard = ({ item, engagement, reach, onDetails }) => {
  return (
    <div className="card">
      <h3>{item.name}</h3>
      <p>Engagement Score: {engagement}</p>
      <p>Reach: {reach}</p>
      <p>Category: {item.category}</p>
      <p>Location: {item.location}</p>
      <button onClick={onDetails}>View Details</button>
    </div>
  );
};

export default ItemCard;
