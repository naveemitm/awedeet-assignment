import React, { useState } from "react";
import mockData from "../mockData";
import ItemCard from "./ItemCard";
import Modal from "./Modal";

const Dashboard = () => {
  const [data, setData] = useState(mockData);
  const [selectedItem, setSelectedItem] = useState(null);
  const [filters, setFilters] = useState({ category: "All", scoreRange: "All" });
  const [sortOption, setSortOption] = useState("");

  // Engagement score calculation
  const calculateEngagement = (item) => item.likes + item.shares + item.comments;

  // Reach calculation
  const calculateReach = (item) =>
    Math.round((item.followers * calculateEngagement(item)) / 100);

  // Filtering logic
  const filteredData = data.filter((item) => {
    const engagement = calculateEngagement(item);

    if (filters.category !== "All" && item.category !== filters.category) {
      return false;
    }

    if (filters.scoreRange !== "All") {
      const [min, max] = filters.scoreRange.split("-").map(Number);
      if (engagement < min || engagement > max) return false;
    }

    return true;
  });

  // Sorting logic
  const sortedData = [...filteredData].sort((a, b) => {
    if (sortOption === "engagementAsc") {
      return calculateEngagement(a) - calculateEngagement(b);
    } else if (sortOption === "engagementDesc") {
      return calculateEngagement(b) - calculateEngagement(a);
    } else if (sortOption === "reachAsc") {
      return calculateReach(a) - calculateReach(b);
    } else if (sortOption === "reachDesc") {
      return calculateReach(b) - calculateReach(a);
    }
    return 0;
  });

  return (
    <div className="dashboard">
      {/* Filter Options */}
      <div className="filters">
        <select
          onChange={(e) =>
            setFilters({ ...filters, category: e.target.value })
          }
        >
          <option value="All">All Categories</option>
          <option value="Tech">Tech</option>
          <option value="Fashion">Fashion</option>
          <option value="Sports">Sports</option>
        </select>

        <select
          onChange={(e) =>
            setFilters({ ...filters, scoreRange: e.target.value })
          }
        >
          <option value="All">All Scores</option>
          <option value="0-1000">0–1000</option>
          <option value="1000-5000">1000–5000</option>
        </select>

        <select onChange={(e) => setSortOption(e.target.value)}>
          <option value="">Sort By</option>
          <option value="engagementAsc">Engagement (Asc)</option>
          <option value="engagementDesc">Engagement (Desc)</option>
          <option value="reachAsc">Reach (Asc)</option>
          <option value="reachDesc">Reach (Desc)</option>
        </select>
      </div>

      {/* Item Cards */}
      <div className="item-list">
        {sortedData.map((item) => (
          <ItemCard
            key={item.id}
            item={item}
            engagement={calculateEngagement(item)}
            reach={calculateReach(item)}
            onDetails={() => setSelectedItem(item)}
          />
        ))}
      </div>

      {/* Modal */}
      {selectedItem && (
        <Modal item={selectedItem} onClose={() => setSelectedItem(null)} />
      )}
    </div>
  );
};

export default Dashboard;
